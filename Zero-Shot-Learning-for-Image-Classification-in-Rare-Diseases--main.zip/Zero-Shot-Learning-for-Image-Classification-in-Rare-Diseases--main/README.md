# Zero-Shot-Learning-for-Image-Classification-in-Rare-Diseases-
A deep learning web application for classifying rare dermatological diseases from medical images using PyTorch, Flask, and React. Includes both trained model inference and zero-shot classification capabilities.  Configuration
